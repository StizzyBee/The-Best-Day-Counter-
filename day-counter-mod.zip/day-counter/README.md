# Day Counter — Minecraft 26.1.2 Fabric Mod

Displays **"Day: N"** centred just above the hotbar while you play.  
One count = one full day/night cycle (24 000 game ticks). Starts at **Day 0**.

---

## Requirements

| Tool | Version |
|------|---------|
| Java (JDK) | **25** |
| IntelliJ IDEA | 2025.3 or newer |
| Fabric Loader | 0.18.4 |
| Gradle | 9.4 (handled by the wrapper) |

> Minecraft 26.1 is fully unobfuscated, so **no separate mappings file** is needed.

---

## Setup (one-time)

### 1 — Fill in the Fabric API version

Open **`gradle.properties`** and replace `REPLACE_ME_SEE_FABRICMC_NET_DEVELOP` with
the correct Fabric API version for **26.1.2**:

1. Go to <https://fabricmc.net/develop/>
2. Select Minecraft version **26.1.2** from the dropdown.
3. Copy the `fabric_api_version` value shown and paste it into `gradle.properties`.

It will look something like `0.X.X+26.1.2`.

### 2 — Get the Gradle wrapper JAR

The binary `gradle/wrapper/gradle-wrapper.jar` is not included in this ZIP (it is a binary file).
You must create it before anything else will work.

**Option A — you have any version of Gradle installed locally:**
```powershell
# Run this once inside the day-counter folder
gradle wrapper --gradle-version 9.4
```

**Option B — copy from the Fabric Example Mod:**
Clone `https://github.com/FabricMC/fabric-example-mod` (branch `26.1.2`) and copy its
`gradle/wrapper/gradle-wrapper.jar` into your project's `gradle/wrapper/` folder.

> ⚠️ After this step, always use `.\gradlew` (Windows) or `./gradlew` (Mac/Linux),
> **not** the bare `gradle` command. Running `gradle` uses your system-wide Gradle
> which may be the wrong version.

### 3 — Open in IntelliJ IDEA

1. **File → Open** and select the `day-counter` folder.
2. Click **Import Gradle Project** when prompted.
3. In **Settings → Build Tools → Gradle**, make sure the **Gradle JVM** is set to Java 25.
4. Wait for Loom to download Minecraft and Fabric API (~a few minutes first time).

### 4 — Build

```powershell
# Windows
.\gradlew build

# Mac / Linux
./gradlew build
```

The output JAR is at `build/libs/day-counter-1.0.0.jar`.

---

## Install

1. Install **Fabric Loader 0.18.4** for Minecraft **26.1.2** via the Fabric Installer.
2. Download **Fabric API** for 26.1.2 from [Modrinth](https://modrinth.com/mod/fabric-api) or [CurseForge](https://www.curseforge.com/minecraft/mc-mods/fabric-api).
3. Drop both `day-counter-1.0.0.jar` **and** the Fabric API JAR into your `.minecraft/mods/` folder.
4. Launch the game — you'll see **Day: 0** above the hotbar immediately.

---

## Project layout

```
day-counter/
├── build.gradle                          Gradle build script
├── gradle.properties                     Version numbers (edit fabric_api_version here)
├── settings.gradle
├── gradle/wrapper/gradle-wrapper.properties
└── src/
    ├── main/resources/fabric.mod.json    Mod metadata & entrypoints
    └── client/java/com/example/daycounter/
        └── DayCounterClient.java         All the mod logic (HUD rendering)
```
