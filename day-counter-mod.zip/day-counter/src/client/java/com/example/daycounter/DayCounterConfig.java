package com.example.daycounter;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Persistent config for Day Counter.
 * Stored at: .minecraft/config/day-counter.json
 *
 * position values:
 *   TOP_LEFT       – top-left corner (original behaviour)
 *   TOP_RIGHT      – top-right corner
 *   BOTTOM_LEFT    – bottom-left corner (above XP bar)
 *   BOTTOM_RIGHT   – bottom-right corner (above XP bar)
 *   ABOVE_HOTBAR   – horizontally centred, just above hotbar
 *                    (clears health, hunger, and XP bar)
 */
public class DayCounterConfig {

    public enum Position {
        TOP_LEFT,
        TOP_RIGHT,
        BOTTOM_LEFT,
        BOTTOM_RIGHT,
        ABOVE_HOTBAR
    }

    // ── Default ───────────────────────────────────────────────────────────────
    public Position position = Position.TOP_LEFT;

    // ── Serialisation ─────────────────────────────────────────────────────────
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH =
        FabricLoader.getInstance().getConfigDir().resolve("day-counter.json");

    /** Load from disk, or return defaults if the file is missing / unreadable. */
    public static DayCounterConfig load() {
        if (Files.exists(CONFIG_PATH)) {
            try {
                String json = Files.readString(CONFIG_PATH);
                DayCounterConfig cfg = GSON.fromJson(json, DayCounterConfig.class);
                if (cfg != null) return cfg;
            } catch (IOException | com.google.gson.JsonSyntaxException ignored) {
                // Fall through to defaults
            }
        }
        DayCounterConfig defaults = new DayCounterConfig();
        defaults.save(); // write defaults so the user can find/edit the file
        return defaults;
    }

    /** Persist current values to disk. */
    public void save() {
        try {
            Files.writeString(CONFIG_PATH, GSON.toJson(this));
        } catch (IOException e) {
            System.err.println("[day-counter] Failed to save config: " + e.getMessage());
        }
    }
}
