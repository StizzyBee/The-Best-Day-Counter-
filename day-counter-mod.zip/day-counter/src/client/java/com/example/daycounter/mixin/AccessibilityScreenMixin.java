package com.example.daycounter.mixin;

import com.example.daycounter.DayCounterClient;
import com.example.daycounter.DayCounterConfig;
import net.minecraft.client.gui.screens.AccessibilityOptionsScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.options.OptionsSubScreen;
import net.minecraft.client.OptionInstance;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Arrays;
import java.util.List;

/**
 * Injects a "Day Counter Position" cycling button into the vanilla
 * Accessibility Options screen.
 *
 * We extend OptionsSubScreen (the common base for all options screens) and
 * inject at the end of init() so our button is appended after vanilla adds
 * its own options list — no vanilla layout is disturbed.
 *
 * OptionInstance<T> is Minecraft's generic options widget.  We use the
 * cycleButton variant so the player just clicks through the five positions.
 */
@Mixin(AccessibilityOptionsScreen.class)
public abstract class AccessibilityScreenMixin extends OptionsSubScreen {

    // Required by OptionsSubScreen — never called directly by our mixin
    protected AccessibilityScreenMixin(Screen parent, net.minecraft.client.Options options, Component title) {
        super(parent, options, title);
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void dayCounter_addPositionOption(CallbackInfo ci) {
        DayCounterConfig cfg = DayCounterClient.CONFIG;

        // Build the list of enum values in display order
        List<DayCounterConfig.Position> values =
            Arrays.asList(DayCounterConfig.Position.values());

        // OptionInstance with a cycle button — vanilla pattern used by
        // options like "Attack Indicator" and "Narrator".
        OptionInstance<DayCounterConfig.Position> option = new OptionInstance<>(
            // Translation key shown as the button label.
            // Falls back gracefully to the key string if no lang file defines it.
            "options.daycounter.position",

            // Tooltip — shown when the player hovers over the button.
            OptionInstance.noTooltip(),

            // Caption renderer: "Day Counter Position: <VALUE>"
            (caption, value) -> Component.translatable(caption)
                .append(Component.literal(": "))
                .append(Component.literal(friendlyName(value))),

            // Cycle through all Position enum values
            new OptionInstance.Enum<>(values, net.minecraft.client.codec.Codecs.stringResolver(
                DayCounterConfig.Position::name,
                DayCounterConfig.Position::valueOf
            )),

            // Current value
            cfg.position,

            // On change: update live config and save to disk immediately
            newValue -> {
                cfg.position = newValue;
                cfg.save();
            }
        );

        // Add to the options list that OptionsSubScreen already created
        this.list.addSmall(option);
    }

    /** Converts enum names like ABOVE_HOTBAR → "Above Hotbar" for display. */
    private static String friendlyName(DayCounterConfig.Position pos) {
        String raw = pos.name().replace('_', ' ');
        StringBuilder sb = new StringBuilder();
        boolean nextUpper = true;
        for (char c : raw.toCharArray()) {
            sb.append(nextUpper ? Character.toUpperCase(c) : Character.toLowerCase(c));
            nextUpper = (c == ' ');
        }
        return sb.toString();
    }
}
