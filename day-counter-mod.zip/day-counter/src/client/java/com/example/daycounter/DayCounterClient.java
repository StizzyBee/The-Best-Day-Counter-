package com.example.daycounter;

// ── Minecraft client classes (official 26.1 unobfuscated names) ──────────────
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;

// ── Fabric loader ─────────────────────────────────────────────────────────────
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

// ── Fabric API HUD (.hud sub-package) ────────────────────────────────────────
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;

@Environment(EnvType.CLIENT)
public class DayCounterClient implements ClientModInitializer {

    public static final String MOD_ID = "day-counter";

    @Override
    public void onInitializeClient() {
        HudElementRegistry.attachElementAfter(
            VanillaHudElements.HOTBAR,
            Identifier.fromNamespaceAndPath(MOD_ID, "day_counter"),
            DayCounterClient::renderDayCounter
        );
    }

    /**
     * Draws "Day: N" in the top-left corner of the screen.
     *
     * Level.getDayTime() was removed in 26.1 (Mojang replaced it with a clock
     * system). getGameTime() counts total ticks since world creation, so
     * dividing by 24 000 gives completed day-night cycles — exactly what we want.
     *
     * Colors in 26.1 are ARGB: 0xFFFFFFFF = fully opaque white.
     * Using 0xFFFFFF (no alpha byte) would render the text as transparent.
     */
    private static void renderDayCounter(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
        Minecraft client = Minecraft.getInstance();

        // Skip when no world is loaded or the HUD is hidden (F1)
        if (client.level == null || client.options.hideGui) {
            return;
        }

        long day  = client.level.getGameTime() / 24_000L;
        String text = "Day: " + day;

        // Top-left corner, 2 px from each edge — clear of hearts, hunger, armour
        int x = 2;
        int y = 2;

        // graphics.text() is the 26.1 name for what was drawString() before.
        // Last arg = drop shadow (true keeps it readable over any background).
        graphics.text(client.font, text, x, y, 0xFFFFFFFF, true);
    }
}
