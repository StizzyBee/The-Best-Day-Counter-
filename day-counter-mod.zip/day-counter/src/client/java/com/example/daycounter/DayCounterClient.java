package com.example.daycounter;

// ── Minecraft client classes (official 26.1 unobfuscated names) ──────────────
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;

// ── Fabric loader ─────────────────────────────────────────────────────────────
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

// ── Fabric API HUD ────────────────────────────────────────────────────────────
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;

@Environment(EnvType.CLIENT)
public class DayCounterClient implements ClientModInitializer {

    public static final String MOD_ID = "day-counter";

    /**
     * Loaded once at startup; updated live when the player saves settings
     * via the Mod Menu config screen (no world reload required).
     */
    public static DayCounterConfig CONFIG;

    // ── Pixel constants ───────────────────────────────────────────────────────

    /** Gap from the screen edge for corner positions. */
    private static final int EDGE_PAD = 2;

    /**
     * How far up from the bottom for BOTTOM_LEFT / BOTTOM_RIGHT.
     *
     * Clears the full vanilla HUD stack at 1× GUI scale:
     *   Hotbar   22 px
     *   XP bar    5 px
     *   XP text   9 px  (reserved even when XP = 0)
     *   Health   10 px
     *   Hunger   10 px
     *   Armour   10 px  (reserved even when unarmoured)
     *   Padding   6 px
     *   ─────────────
     *   Total    72 px
     */
    private static final int BOTTOM_Y_OFFSET = 72;

    /**
     * How far up from the bottom for ABOVE_HOTBAR.
     *
     * Only needs to clear the hotbar + XP bar because the text is centred
     * and health/hunger live on the sides:
     *   Hotbar   22 px
     *   XP bar    5 px
     *   Padding   4 px
     *   ─────────────
     *   Total    31 px
     */
    private static final int ABOVE_HOTBAR_Y_OFFSET = 31;

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    @Override
    public void onInitializeClient() {
        CONFIG = DayCounterConfig.load();

        HudElementRegistry.attachElementAfter(
            VanillaHudElements.HOTBAR,
            Identifier.fromNamespaceAndPath(MOD_ID, "day_counter"),
            DayCounterClient::renderDayCounter
        );
    }

    // ── Render ────────────────────────────────────────────────────────────────

    private static void renderDayCounter(GuiGraphicsExtractor graphics, DeltaTracker deltaTracker) {
        Minecraft client = Minecraft.getInstance();

        if (client.level == null || client.options.hideGui) return;

        long day    = client.level.getGameTime() / 24_000L;
        String text = "Day: " + day;

        int screenW = client.getWindow().getGuiScaledWidth();
        int screenH = client.getWindow().getGuiScaledHeight();
        int textW   = client.font.width(text);
        int textH   = client.font.lineHeight; // 9 px at 1× GUI scale

        int x, y;

        switch (CONFIG.position) {

            case TOP_RIGHT:
                x = screenW - textW - EDGE_PAD;
                y = EDGE_PAD;
                break;

            case BOTTOM_LEFT:
                x = EDGE_PAD;
                y = screenH - BOTTOM_Y_OFFSET - textH;
                break;

            case BOTTOM_RIGHT:
                x = screenW - textW - EDGE_PAD;
                y = screenH - BOTTOM_Y_OFFSET - textH;
                break;

            case ABOVE_HOTBAR:
                x = (screenW - textW) / 2;
                y = screenH - ABOVE_HOTBAR_Y_OFFSET - textH;
                break;

            case TOP_LEFT:
            default:
                x = EDGE_PAD;
                y = EDGE_PAD;
                break;
        }

        graphics.text(client.font, text, x, y, 0xFFFFFFFF, true);
    }
}
